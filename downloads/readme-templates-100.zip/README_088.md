# ToolFarm-87

Автономная ферма 87 — 1500 инструментов

## Установка
```bash
npm install
```
## Использование
```js
import wordCounter from './tool'
```
## Лицензия MIT