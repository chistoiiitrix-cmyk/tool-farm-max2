# ToolFarm-61

Автономная ферма 61 — 1500 инструментов

## Установка
```bash
npm install
```
## Использование
```js
import wordCounter from './tool'
```
## Лицензия MIT