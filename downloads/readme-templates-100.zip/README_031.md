# ToolFarm-30

Автономная ферма 30 — 1500 инструментов

## Установка
```bash
npm install
```
## Использование
```js
import wordCounter from './tool'
```
## Лицензия MIT