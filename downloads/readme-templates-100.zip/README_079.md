# ToolFarm-78

Автономная ферма 78 — 1500 инструментов

## Установка
```bash
npm install
```
## Использование
```js
import wordCounter from './tool'
```
## Лицензия MIT