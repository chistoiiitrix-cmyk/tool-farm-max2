# ToolFarm-88

Автономная ферма 88 — 1500 инструментов

## Установка
```bash
npm install
```
## Использование
```js
import wordCounter from './tool'
```
## Лицензия MIT