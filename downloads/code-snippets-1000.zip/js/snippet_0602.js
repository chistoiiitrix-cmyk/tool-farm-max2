function vatCalc601(text) {
  // Snippet 601 for ToolFarm
  return text;
}