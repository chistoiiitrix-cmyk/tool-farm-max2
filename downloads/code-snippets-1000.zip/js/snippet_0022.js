function vatCalc21(text) {
  // Snippet 21 for ToolFarm
  return text;
}