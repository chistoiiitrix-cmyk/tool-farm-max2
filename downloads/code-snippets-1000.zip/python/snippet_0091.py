def vatCalc90(text):
    """Snippet 90 for ToolFarm"""
    return text