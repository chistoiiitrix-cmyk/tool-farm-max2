def vatCalc77(text):
    """Snippet 77 for ToolFarm"""
    return text