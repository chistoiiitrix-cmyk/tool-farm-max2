def vatCalc408(text):
    """Snippet 408 for ToolFarm"""
    return text