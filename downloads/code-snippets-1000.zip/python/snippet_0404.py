def vatCalc403(text):
    """Snippet 403 for ToolFarm"""
    return text