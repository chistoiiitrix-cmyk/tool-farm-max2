def wordCounter101(text):
    """Snippet 101 for ToolFarm"""
    return text