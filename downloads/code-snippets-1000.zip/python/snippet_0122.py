def vatCalc121(text):
    """Snippet 121 for ToolFarm"""
    return text