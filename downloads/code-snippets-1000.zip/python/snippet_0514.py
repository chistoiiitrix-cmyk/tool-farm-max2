def vatCalc513(text):
    """Snippet 513 for ToolFarm"""
    return text