def wordCounter5(text):
    """Snippet 5 for ToolFarm"""
    return text