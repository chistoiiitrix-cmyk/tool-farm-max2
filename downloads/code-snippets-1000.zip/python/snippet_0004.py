def removeDuplicates3(text):
    """Snippet 3 for ToolFarm"""
    return text