def vatCalc500(text):
    """Snippet 500 for ToolFarm"""
    return text