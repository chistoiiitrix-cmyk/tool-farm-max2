def vatCalc120(text):
    """Snippet 120 for ToolFarm"""
    return text