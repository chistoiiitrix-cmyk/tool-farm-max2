def vatCalc300(text):
    """Snippet 300 for ToolFarm"""
    return text