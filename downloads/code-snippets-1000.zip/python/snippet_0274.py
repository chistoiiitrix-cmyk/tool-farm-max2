def vatCalc273(text):
    """Snippet 273 for ToolFarm"""
    return text