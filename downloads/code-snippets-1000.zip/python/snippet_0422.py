def vatCalc421(text):
    """Snippet 421 for ToolFarm"""
    return text