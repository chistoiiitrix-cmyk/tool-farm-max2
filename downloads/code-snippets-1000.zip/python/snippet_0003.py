def removeDuplicates2(text):
    """Snippet 2 for ToolFarm"""
    return text