def vatCalc572(text):
    """Snippet 572 for ToolFarm"""
    return text