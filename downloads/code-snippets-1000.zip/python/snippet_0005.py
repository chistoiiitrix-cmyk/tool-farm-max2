def wordCounter4(text):
    """Snippet 4 for ToolFarm"""
    return text