def vatCalc704(text):
    """Snippet 704 for ToolFarm"""
    return text